# Utils

def first(a_list):
    return a_list[0]


def last(a_list):
    return a_list[-1]
